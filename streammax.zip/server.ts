import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import cors from 'cors';

const JWT_SECRET = 'streammax_ultra_secure_key_2026_manuel_mods';
const ADMIN_USER = 'Manuel mods games';
const ADMIN_PASS = 'j0$3 man~3l';
const ADMIN_PASS_HASH = bcrypt.hashSync(ADMIN_PASS, 10);


const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Ensure upload directory exists
const UPLOAD_DIR = path.join(process.cwd(), 'public/uploads');
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// Simple JSON Database
const DB_PATH = path.join(process.cwd(), 'db.json');
if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify({ users: [], content: [], notifications: [] }));
}

const getDB = () => JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
const saveDB = (data: any) => fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));

const addNotification = (toUser: string, fromUser: string, message: string, contentId?: string) => {
  const db = getDB();
  db.notifications.push({
    id: Date.now().toString(),
    toUser,
    fromUser,
    message,
    contentId,
    read: false,
    createdAt: new Date().toISOString()
  });
  saveDB(db);
};

// Multer for uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(process.cwd(), 'public/uploads');
    if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// Auth Middleware
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// API Routes
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  const db = getDB();
  if (db.users.find((u: any) => u.username === username)) {
    return res.status(400).json({ error: 'Usuario ya existe' });
  }
  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser = { 
    id: Date.now().toString(), 
    username, 
    password: hashedPassword, 
    isVerified: username === ADMIN_USER,
    bio: '',
    profilePic: '',
    followers: [],
    following: []
  };
  db.users.push(newUser);
  saveDB(db);
  res.json({ success: true });
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const db = getDB();
  const user = db.users.find((u: any) => u.username === username);
  
  // Special check for Manuel
  if (username === ADMIN_USER) {
    if (bcrypt.compareSync(password, ADMIN_PASS_HASH)) {
      const dbUser = db.users.find((u: any) => u.username === ADMIN_USER);
      const token = jwt.sign({ id: 'admin', username: ADMIN_USER, isAdmin: true }, JWT_SECRET);
      return res.json({ 
        token, 
        user: { 
          username: ADMIN_USER, 
          isVerified: true, 
          isAdmin: true, 
          bio: dbUser?.bio || '', 
          profilePic: dbUser?.profilePic || '', 
          followers: dbUser?.followers || [], 
          following: dbUser?.following || [] 
        } 
      });
    }
  }

  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(400).json({ error: 'Credenciales inválidas' });
  }
  const token = jwt.sign({ id: user.id, username: user.username, isAdmin: user.username === ADMIN_USER }, JWT_SECRET);
  res.json({ token, user: { username: user.username, isVerified: user.isVerified, isAdmin: user.username === ADMIN_USER, bio: user.bio || '', profilePic: user.profilePic || '', followers: user.followers || [], following: user.following || [] } });
});

app.get('/api/content', (req, res) => {
  const db = getDB();
  res.json(db.content);
});

app.post('/api/upload', authenticateToken, upload.fields([{ name: 'file', maxCount: 1 }, { name: 'thumbnail', maxCount: 1 }]), (req: any, res) => {
  const { title, type, description } = req.body;
  const db = getDB();
  const files = req.files as { [fieldname: string]: Express.Multer.File[] };
  
  const mainFile = files['file']?.[0];
  const thumbFile = files['thumbnail']?.[0];

  if (!mainFile) return res.status(400).json({ error: 'Archivo principal requerido' });

  const newContent = {
    id: Date.now().toString(),
    title,
    type, // 'video' or 'music'
    description,
    url: `/uploads/${mainFile.filename}`,
    thumbnailUrl: thumbFile ? `/uploads/${thumbFile.filename}` : '',
    author: req.user.username,
    createdAt: new Date().toISOString(),
    likes: [],
    dislikes: [],
    comments: [],
    favorites: []
  };
  db.content.push(newContent);
  saveDB(db);
  res.json(newContent);
});

app.get('/api/users/:username', (req, res) => {
  const { username } = req.params;
  const db = getDB();
  const user = db.users.find((u: any) => u.username === username);
  if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });
  
  const { password, ...safeUser } = user;
  res.json(safeUser);
});

app.post('/api/profile/update', authenticateToken, upload.single('profilePic'), (req: any, res) => {
  const { bio } = req.body;
  const db = getDB();
  const user = db.users.find((u: any) => u.username === req.user.username);
  
  if (user) {
    if (bio !== undefined) user.bio = bio;
    if (req.file) user.profilePic = `/uploads/${req.file.filename}`;
    saveDB(db);
    const { password, ...safeUser } = user;
    res.json(safeUser);
  } else {
    res.status(404).json({ error: 'Usuario no encontrado' });
  }
});

app.post('/api/content/:id/like', authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const db = getDB();
  const item = db.content.find((c: any) => c.id === id);
  if (!item) return res.status(404).json({ error: 'No encontrado' });

  if (!item.likes.includes(req.user.username)) {
    item.likes.push(req.user.username);
    item.dislikes = item.dislikes.filter((u: string) => u !== req.user.username);
    addNotification(item.author, req.user.username, `le dio like a tu ${item.type}`, id);
  } else {
    item.likes = item.likes.filter((u: string) => u !== req.user.username);
  }
  saveDB(db);
  res.json({ likes: item.likes, dislikes: item.dislikes });
});

app.post('/api/content/:id/dislike', authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const db = getDB();
  const item = db.content.find((c: any) => c.id === id);
  if (!item) return res.status(404).json({ error: 'No encontrado' });

  if (!item.dislikes.includes(req.user.username)) {
    item.dislikes.push(req.user.username);
    item.likes = item.likes.filter((u: string) => u !== req.user.username);
  } else {
    item.dislikes = item.dislikes.filter((u: string) => u !== req.user.username);
  }
  saveDB(db);
  res.json({ likes: item.likes, dislikes: item.dislikes });
});

app.post('/api/content/:id/comment', authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const { text } = req.body;
  const db = getDB();
  const item = db.content.find((c: any) => c.id === id);
  if (!item) return res.status(404).json({ error: 'No encontrado' });

  const comment = {
    id: Date.now().toString(),
    username: req.user.username,
    text,
    createdAt: new Date().toISOString()
  };
  item.comments.push(comment);
  addNotification(item.author, req.user.username, `comentó en tu ${item.type}: "${text.substring(0, 20)}..."`, id);
  saveDB(db);
  res.json(comment);
});

app.post('/api/content/:id/favorite', authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const db = getDB();
  const item = db.content.find((c: any) => c.id === id);
  if (!item) return res.status(404).json({ error: 'No encontrado' });

  if (!item.favorites) item.favorites = [];
  if (!item.favorites.includes(req.user.username)) {
    item.favorites.push(req.user.username);
  } else {
    item.favorites = item.favorites.filter((u: string) => u !== req.user.username);
  }
  saveDB(db);
  res.json({ favorites: item.favorites });
});

app.get('/api/notifications', authenticateToken, (req: any, res) => {
  const db = getDB();
  const userNotifications = db.notifications
    .filter((n: any) => n.toUser === req.user.username)
    .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json(userNotifications);
});

app.post('/api/notifications/read', authenticateToken, (req: any, res) => {
  const db = getDB();
  db.notifications.forEach((n: any) => {
    if (n.toUser === req.user.username) n.read = true;
  });
  saveDB(db);
  res.json({ success: true });
});

app.post('/api/verify', authenticateToken, (req: any, res) => {
  if (!req.user.isAdmin) return res.status(403).json({ error: 'No autorizado' });
  const { username, action } = req.body; // action: 'verify' or 'unverify'
  const db = getDB();
  const user = db.users.find((u: any) => u.username === username);
  if (user) {
    user.isVerified = action !== 'unverify';
    saveDB(db);
    res.json({ success: true, isVerified: user.isVerified });
  } else {
    res.status(404).json({ error: 'Usuario no encontrado' });
  }
});

app.delete('/api/content/:id', authenticateToken, (req: any, res) => {
  if (!req.user.isAdmin) return res.status(403).json({ error: 'No autorizado' });
  const { id } = req.params;
  const db = getDB();
  db.content = db.content.filter((c: any) => c.id !== id);
  saveDB(db);
  res.json({ success: true });
});

app.delete('/api/users/:username', authenticateToken, (req: any, res) => {
  if (!req.user.isAdmin) return res.status(403).json({ error: 'No autorizado' });
  const { username } = req.params;
  const db = getDB();
  db.users = db.users.filter((u: any) => u.username !== username);
  db.content = db.content.filter((c: any) => c.author !== username);
  saveDB(db);
  res.json({ success: true });
});

app.get('/api/search', (req, res) => {
  const { q } = req.query;
  if (!q) return res.json({ users: [], content: [] });
  
  const query = (q as string).toLowerCase();
  const db = getDB();
  
  const users = db.users
    .filter((u: any) => u.username.toLowerCase().includes(query))
    .map(({ password, ...u }: any) => u);
    
  const content = db.content.filter((c: any) => 
    c.title.toLowerCase().includes(query) || 
    c.description.toLowerCase().includes(query) ||
    c.author.toLowerCase().includes(query)
  );
  
  res.json({ users, content });
});

app.post('/api/users/:username/follow', authenticateToken, (req: any, res) => {
  const { username } = req.params;
  const db = getDB();
  const targetUser = db.users.find((u: any) => u.username === username);
  const currentUser = db.users.find((u: any) => u.username === req.user.username);
  
  if (!targetUser || !currentUser) return res.status(404).json({ error: 'Usuario no encontrado' });
  if (targetUser.username === currentUser.username) return res.status(400).json({ error: 'No puedes seguirte a ti mismo' });

  if (!targetUser.followers) targetUser.followers = [];
  if (!currentUser.following) currentUser.following = [];

  if (!targetUser.followers.includes(currentUser.username)) {
    targetUser.followers.push(currentUser.username);
    currentUser.following.push(targetUser.username);
    addNotification(targetUser.username, currentUser.username, 'comenzó a seguirte');
  } else {
    targetUser.followers = targetUser.followers.filter((u: string) => u !== currentUser.username);
    currentUser.following = currentUser.following.filter((u: string) => u !== targetUser.username);
  }
  
  saveDB(db);
  res.json({ followers: targetUser.followers, following: currentUser.following });
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

app.use('/uploads', express.static(path.join(process.cwd(), 'public/uploads')));
app.use(express.static(path.join(process.cwd(), 'public')));

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);

    // Fallback for SPA in dev
    app.get('*', async (req, res, next) => {
      if (req.url.startsWith('/api')) return next();
      try {
        let template = fs.readFileSync(path.resolve(process.cwd(), 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(req.url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    app.use(express.static(path.join(process.cwd(), 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(process.cwd(), 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
