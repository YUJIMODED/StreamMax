import React, { useState, useEffect, createContext, useContext } from 'react';
import { 
  Play, 
  Music, 
  Search, 
  User as UserIcon, 
  Bell, 
  Upload, 
  Heart, 
  MessageCircle, 
  Share2, 
  CheckCircle, 
  Trash2, 
  ShieldCheck,
  LogOut,
  Home,
  Library,
  Menu,
  X,
  MoreVertical,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User, Content, Notification } from './types';

const API_BASE = import.meta.env.VITE_API_URL || '';

// --- Auth Context ---
interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (token: string, user: User) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const savedToken = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const login = (newToken: string, newUser: User) => {
    setToken(newToken);
    setUser(newUser);
    localStorage.setItem('token', newToken);
    localStorage.setItem('user', JSON.stringify(newUser));
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

const useAuth = () => useContext(AuthContext)!;

// --- Components ---

const Navbar: React.FC<{ 
  onOpenUpload: () => void, 
  onOpenNotifications: () => void, 
  onOpenProfile: () => void,
  onSearch: (query: string) => void 
}> = ({ onOpenUpload, onOpenNotifications, onOpenProfile, onSearch }) => {
  const { user, logout } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 h-16 bg-black/80 backdrop-blur-md border-b border-zinc-800 z-50 flex items-center justify-between px-4 md:px-8">
      <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.location.reload()}>
        <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center">
          <Play className="text-white fill-current" size={18} />
        </div>
        <span className="text-xl font-bold tracking-tighter">StreamMax</span>
      </div>

      <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xl mx-8">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar videos, música o creadores..." 
            className="w-full bg-zinc-900 border border-zinc-800 rounded-full py-2 pl-10 pr-4 focus:outline-none focus:border-zinc-600 transition-all"
          />
        </div>
      </form>

      <div className="flex items-center gap-4">
        {user ? (
          <>
            <button onClick={onOpenUpload} className="p-2 hover:bg-zinc-800 rounded-full transition-colors text-zinc-400 hover:text-white">
              <Upload size={22} />
            </button>
            <button onClick={onOpenNotifications} className="p-2 hover:bg-zinc-800 rounded-full transition-colors text-zinc-400 hover:text-white relative">
              <Bell size={22} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-600 rounded-full border border-black"></span>
            </button>
            <div className="relative">
              <button 
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="w-9 h-9 bg-zinc-800 rounded-full flex items-center justify-center overflow-hidden border border-zinc-700 hover:border-zinc-500 transition-all"
              >
                {user.profilePic ? (
                  <img src={user.profilePic} alt={user.username} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <UserIcon size={20} className="text-zinc-400" />
                )}
              </button>
              
              <AnimatePresence>
                {showUserMenu && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute right-0 mt-2 w-56 bg-zinc-900 border border-zinc-800 rounded-xl shadow-2xl overflow-hidden z-50"
                  >
                    <div className="p-4 border-b border-zinc-800">
                      <div className="flex items-center gap-2">
                        <span className="font-bold">@{user.username}</span>
                        {user.isVerified && <CheckCircle size={14} className="text-blue-500 fill-current" />}
                      </div>
                      <p className="text-xs text-zinc-500 mt-0.5">Soporte: rj757814007@gmail.com</p>
                    </div>
                    <div className="p-2">
                      <button 
                        onClick={() => { onOpenProfile(); setShowUserMenu(false); }}
                        className="w-full flex items-center gap-3 px-3 py-2 hover:bg-zinc-800 rounded-lg transition-colors text-sm"
                      >
                        <UserIcon size={18} /> Mi Perfil
                      </button>
                      {user.isAdmin && (
                        <button className="w-full flex items-center gap-3 px-3 py-2 hover:bg-zinc-800 rounded-lg transition-colors text-sm text-red-500">
                          <ShieldCheck size={18} /> Panel de Amo
                        </button>
                      )}
                      <button 
                        onClick={logout}
                        className="w-full flex items-center gap-3 px-3 py-2 hover:bg-zinc-800 rounded-lg transition-colors text-sm text-zinc-400"
                      >
                        <LogOut size={18} /> Cerrar Sesión
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </>
        ) : (
          <button className="btn-primary text-sm font-bold">Iniciar Sesión</button>
        )}
      </div>
    </nav>
  );
};

const Sidebar: React.FC = () => {
  return (
    <aside className="fixed left-0 top-16 bottom-0 w-64 bg-black border-r border-zinc-800 hidden lg:flex flex-col p-4 gap-2">
      <SidebarItem icon={<Home size={20} />} label="Inicio" active />
      <SidebarItem icon={<Search size={20} />} label="Explorar" />
      <SidebarItem icon={<Bell size={20} />} label="Suscripciones" />
      <SidebarItem icon={<Library size={20} />} label="Biblioteca" />
      
      <div className="h-px bg-zinc-800 my-4"></div>
      
      <h3 className="text-xs font-bold text-zinc-500 uppercase px-4 mb-2">Tu Música</h3>
      <SidebarItem icon={<Music size={20} />} label="Favoritos" />
      <SidebarItem icon={<Play size={20} />} label="Playlists" />
    </aside>
  );
};

const SidebarItem: React.FC<{ icon: React.ReactNode, label: string, active?: boolean }> = ({ icon, label, active }) => (
  <button className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${active ? 'bg-zinc-900 text-white' : 'text-zinc-400 hover:bg-zinc-900 hover:text-white'}`}>
    {icon}
    <span className="font-medium">{label}</span>
  </button>
);

const ContentCard: React.FC<{ content: Content, onAdminDelete?: (id: string) => void, onClick: () => void }> = ({ content, onAdminDelete, onClick }) => {
  const { user } = useAuth();
  
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      onClick={onClick}
      className="bg-zinc-900/30 rounded-2xl overflow-hidden border border-zinc-800 hover:border-zinc-700 transition-all group cursor-pointer"
    >
      <div className="aspect-video bg-zinc-800 relative overflow-hidden">
        {content.thumbnailUrl ? (
          <img src={content.thumbnailUrl} alt={content.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-zinc-800 to-zinc-900">
            {content.type === 'video' ? (
              <Play size={48} className="text-zinc-600 group-hover:text-red-600 transition-colors" />
            ) : (
              <Music size={48} className="text-zinc-600 group-hover:text-blue-500 transition-colors" />
            )}
          </div>
        )}
        <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest">
          {content.type}
        </div>
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center">
            <Play size={24} className="text-white fill-current" />
          </div>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start gap-2">
          <h3 className="font-bold line-clamp-1">{content.title}</h3>
          {user?.isAdmin && (
            <button 
              onClick={(e) => { e.stopPropagation(); onAdminDelete?.(content.id); }}
              className="p-1.5 text-zinc-500 hover:text-red-500 transition-colors"
            >
              <Trash2 size={16} />
            </button>
          )}
        </div>
        
        <div className="flex items-center gap-2 mt-2">
          <div className="w-6 h-6 bg-zinc-800 rounded-full flex items-center justify-center text-[10px] font-bold overflow-hidden">
            {content.author[0].toUpperCase()}
          </div>
          <div className="flex items-center gap-1">
            <span className="text-xs text-zinc-400 font-medium">@{content.author}</span>
            <CheckCircle size={10} className="text-blue-500 fill-current" />
          </div>
        </div>
        
        <div className="flex items-center gap-4 mt-4 text-zinc-500">
          <button className="flex items-center gap-1.5 hover:text-red-500 transition-colors">
            <ThumbsUp size={16} />
            <span className="text-xs font-bold">{content.likes.length}</span>
          </button>
          <button className="flex items-center gap-1.5 hover:text-white transition-colors">
            <MessageCircle size={16} />
            <span className="text-xs font-bold">{content.comments.length}</span>
          </button>
          <button className="flex items-center gap-1.5 hover:text-white transition-colors ml-auto">
            <Share2 size={16} />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

const AuthModal: React.FC<{ isOpen: boolean, onClose: () => void }> = ({ isOpen, onClose }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const endpoint = isLogin ? `${API_BASE}/api/login` : `${API_BASE}/api/register`;
    
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      
      if (res.ok) {
        if (isLogin) {
          login(data.token, data.user);
          onClose();
        } else {
          setIsLogin(true);
          setError('Cuenta creada. Inicia sesión.');
        }
      } else {
        setError(data.error || 'Algo salió mal');
      }
    } catch (err) {
      setError('Error de conexión');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-8 shadow-2xl"
          >
            <h2 className="text-3xl font-black tracking-tighter mb-2">
              {isLogin ? 'Bienvenido a StreamMax' : 'Únete a la Élite'}
            </h2>
            <p className="text-zinc-500 text-sm mb-8">
              {isLogin ? 'Ingresa tus credenciales para continuar.' : 'Crea tu cuenta única y comienza a subir contenido.'}
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-2 ml-1">Usuario</label>
                <input 
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Tu nombre de usuario" 
                  className="input-field w-full"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-2 ml-1">Contraseña</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••" 
                  className="input-field w-full"
                  required
                />
              </div>
              
              {error && <p className="text-red-500 text-xs font-bold text-center">{error}</p>}

              <button type="submit" className="btn-primary w-full py-3 font-black text-lg mt-4">
                {isLogin ? 'INICIAR SESIÓN' : 'CREAR CUENTA'}
              </button>
            </form>

            <div className="mt-8 text-center">
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-zinc-500 hover:text-white text-sm font-medium transition-colors"
              >
                {isLogin ? '¿No tienes cuenta? Regístrate' : '¿Ya tienes cuenta? Inicia sesión'}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const UploadModal: React.FC<{ isOpen: boolean, onClose: () => void, onUploadSuccess: () => void }> = ({ isOpen, onClose, onUploadSuccess }) => {
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'video' | 'music'>('video');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const { token } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;
    setLoading(true);

    const formData = new FormData();
    formData.append('title', title);
    formData.append('type', type);
    formData.append('description', description);
    formData.append('file', file);
    if (thumbnail) formData.append('thumbnail', thumbnail);

    try {
      const res = await fetch(`${API_BASE}/api/upload`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      if (res.ok) {
        onUploadSuccess();
        onClose();
        setTitle('');
        setDescription('');
        setFile(null);
        setThumbnail(null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative w-full max-w-lg bg-zinc-900 border border-zinc-800 rounded-3xl p-8 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-black mb-6">Subir Contenido</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input type="text" placeholder="Título" value={title} onChange={(e) => setTitle(e.target.value)} className="input-field w-full" required />
              <select value={type} onChange={(e) => setType(e.target.value as any)} className="input-field w-full">
                <option value="video">Video</option>
                <option value="music">Música</option>
              </select>
              <textarea placeholder="Descripción" value={description} onChange={(e) => setDescription(e.target.value)} className="input-field w-full h-24 resize-none" />
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Archivo Principal</label>
                  <div className="border-2 border-dashed border-zinc-800 rounded-2xl p-4 text-center hover:border-red-600 transition-colors cursor-pointer relative">
                    <input 
                      type="file" 
                      onChange={(e) => setFile(e.target.files?.[0] || null)} 
                      className="absolute inset-0 opacity-0 cursor-pointer" 
                      accept={type === 'video' ? 'video/*' : 'audio/*'}
                    />
                    <Upload className="mx-auto text-zinc-500 mb-1" size={24} />
                    <p className="text-[10px] text-zinc-400 font-medium truncate">
                      {file ? file.name : `Archivo`}
                    </p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Miniatura (Opcional)</label>
                  <div className="border-2 border-dashed border-zinc-800 rounded-2xl p-4 text-center hover:border-blue-600 transition-colors cursor-pointer relative">
                    <input 
                      type="file" 
                      onChange={(e) => setThumbnail(e.target.files?.[0] || null)} 
                      className="absolute inset-0 opacity-0 cursor-pointer" 
                      accept="image/*"
                    />
                    <UserIcon className="mx-auto text-zinc-500 mb-1" size={24} />
                    <p className="text-[10px] text-zinc-400 font-medium truncate">
                      {thumbnail ? thumbnail.name : `Imagen`}
                    </p>
                  </div>
                </div>
              </div>

              <button disabled={loading} type="submit" className="btn-primary w-full py-3 font-black mt-4">
                {loading ? 'SUBIENDO...' : 'PUBLICAR AHORA'}
              </button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const NotificationsModal: React.FC<{ isOpen: boolean, onClose: () => void }> = ({ isOpen, onClose }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { token } = useAuth();

  useEffect(() => {
    if (isOpen && token) {
      fetch(`${API_BASE}/api/notifications`, {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(data => setNotifications(data));
      
      // Mark as read
      fetch(`${API_BASE}/api/notifications/read`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
    }
  }, [isOpen, token]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
          <motion.div initial={{ x: 300, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: 300, opacity: 0 }} className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-zinc-900 border-l border-zinc-800 p-8">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-black">Notificaciones</h2>
              <button onClick={onClose} className="p-2 hover:bg-zinc-800 rounded-full"><X /></button>
            </div>
            <div className="space-y-4 overflow-y-auto max-h-[calc(100vh-150px)] pr-2">
              {notifications.length > 0 ? notifications.map(n => (
                <div key={n.id} className={`p-4 rounded-2xl border ${n.read ? 'bg-zinc-900/50 border-zinc-800' : 'bg-red-600/10 border-red-600/30'} transition-all`}>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-zinc-800 rounded-full flex items-center justify-center font-bold text-xs">
                      {n.fromUser[0].toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm">
                        <span className="font-bold">@{n.fromUser}</span> {n.message}
                      </p>
                      <p className="text-[10px] text-zinc-500 mt-1">{new Date(n.createdAt).toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              )) : (
                <div className="text-center py-20 text-zinc-500">
                  <Bell size={48} className="mx-auto mb-4 opacity-20" />
                  <p className="font-medium">No tienes notificaciones aún.</p>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const MobileNav: React.FC<{ 
  onOpenUpload: () => void, 
  onOpenNotifications: () => void, 
  onOpenProfile: () => void 
}> = ({ onOpenUpload, onOpenNotifications, onOpenProfile }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 h-16 bg-black/90 backdrop-blur-lg border-t border-zinc-800 z-50 flex items-center justify-around lg:hidden px-2">
      <button className="flex flex-col items-center gap-1 text-white">
        <Home size={20} />
        <span className="text-[10px] font-bold uppercase">Inicio</span>
      </button>
      <button className="flex flex-col items-center gap-1 text-zinc-500">
        <Search size={20} />
        <span className="text-[10px] font-bold uppercase">Explorar</span>
      </button>
      <button onClick={onOpenUpload} className="flex flex-col items-center gap-1 text-zinc-500">
        <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center -mt-8 border-4 border-black shadow-lg">
          <Upload size={20} className="text-white" />
        </div>
        <span className="text-[10px] font-bold uppercase mt-1">Subir</span>
      </button>
      <button onClick={onOpenNotifications} className="flex flex-col items-center gap-1 text-zinc-500">
        <Bell size={20} />
        <span className="text-[10px] font-bold uppercase">Avisos</span>
      </button>
      <button onClick={onOpenProfile} className="flex flex-col items-center gap-1 text-zinc-500">
        <UserIcon size={20} />
        <span className="text-[10px] font-bold uppercase">Perfil</span>
      </button>
    </nav>
  );
};

// --- Main App ---

const PlayerModal: React.FC<{ content: Content | null, onClose: () => void, onUpdate: () => void }> = ({ content, onClose, onUpdate }) => {
  const { user, token } = useAuth();
  const [commentText, setCommentText] = useState('');
  const [isLiking, setIsLiking] = useState(false);

  if (!content) return null;

  const handleLike = async () => {
    if (!token || isLiking) return;
    setIsLiking(true);
    try {
      await fetch(`${API_BASE}/api/content/${content.id}/like`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      onUpdate();
    } catch (err) {
      console.error(err);
    } finally {
      setIsLiking(false);
    }
  };

  const handleDislike = async () => {
    if (!token || isLiking) return;
    setIsLiking(true);
    try {
      await fetch(`${API_BASE}/api/content/${content.id}/dislike`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      onUpdate();
    } catch (err) {
      console.error(err);
    } finally {
      setIsLiking(false);
    }
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !commentText.trim()) return;
    try {
      const res = await fetch(`${API_BASE}/api/content/${content.id}/comment`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify({ text: commentText })
      });
      if (res.ok) {
        setCommentText('');
        onUpdate();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleFollow = async () => {
    if (!token) return;
    try {
      await fetch(`${API_BASE}/api/users/${content.author}/follow`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      onUpdate();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[150] flex items-center justify-center p-0 md:p-4">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-black/95 backdrop-blur-xl" />
        <motion.div 
          initial={{ y: 100, opacity: 0 }} 
          animate={{ y: 0, opacity: 1 }} 
          exit={{ y: 100, opacity: 0 }} 
          className="relative w-full max-w-6xl bg-zinc-950 border border-zinc-800 md:rounded-3xl overflow-hidden flex flex-col md:flex-row h-full md:h-[85vh]"
        >
          <div className="flex-1 bg-black flex items-center justify-center relative group">
            {content.type === 'video' ? (
              <video src={content.url} controls autoPlay className="w-full h-full max-h-full object-contain" />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
                <div className="w-48 h-48 bg-zinc-900 rounded-3xl shadow-2xl mb-8 flex items-center justify-center overflow-hidden border border-zinc-800">
                  {content.thumbnailUrl ? (
                    <img src={content.thumbnailUrl} alt={content.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <Music size={80} className="text-zinc-700" />
                  )}
                </div>
                <h2 className="text-3xl font-black mb-2">{content.title}</h2>
                <p className="text-zinc-500 font-bold mb-8">@{content.author}</p>
                <audio src={content.url} controls autoPlay className="w-full max-w-md" />
              </div>
            )}
            <button onClick={onClose} className="absolute top-4 left-4 p-2 bg-black/50 hover:bg-black rounded-full text-white transition-colors z-10">
              <X size={24} />
            </button>
          </div>

          <div className="w-full md:w-96 bg-zinc-900 border-l border-zinc-800 flex flex-col">
            <div className="p-6 border-b border-zinc-800">
              <h3 className="text-xl font-black mb-2">{content.title}</h3>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-zinc-800 rounded-full flex items-center justify-center font-bold text-xs">
                    {content.author[0].toUpperCase()}
                  </div>
                  <span className="font-bold text-sm">@{content.author}</span>
                  <CheckCircle size={12} className="text-blue-500 fill-current" />
                </div>
                {user && user.username !== content.author && (
                  <button 
                    onClick={handleFollow}
                    className="text-xs font-bold bg-white text-black px-3 py-1.5 rounded-full hover:bg-zinc-200 transition-colors"
                  >
                    Seguir
                  </button>
                )}
              </div>
              
              <div className="flex items-center gap-4 mb-4">
                <button 
                  onClick={handleLike}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all ${content.likes.includes(user?.username || '') ? 'bg-red-600 border-red-600 text-white' : 'border-zinc-800 text-zinc-400 hover:border-zinc-600'}`}
                >
                  <ThumbsUp size={16} />
                  <span className="text-xs font-bold">{content.likes.length}</span>
                </button>
                <button 
                  onClick={handleDislike}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all ${content.dislikes.includes(user?.username || '') ? 'bg-zinc-700 border-zinc-700 text-white' : 'border-zinc-800 text-zinc-400 hover:border-zinc-600'}`}
                >
                  <ThumbsDown size={16} />
                </button>
              </div>

              <p className="text-sm text-zinc-400 line-clamp-3">{content.description}</p>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <h4 className="text-xs font-black text-zinc-500 uppercase tracking-widest">Comentarios ({content.comments.length})</h4>
              {content.comments.map(c => (
                <div key={c.id} className="bg-zinc-800/50 p-3 rounded-xl border border-zinc-800">
                  <p className="text-xs font-bold text-zinc-400 mb-1">@{c.username}</p>
                  <p className="text-sm">{c.text}</p>
                </div>
              ))}
              {content.comments.length === 0 && (
                <p className="text-center py-10 text-zinc-600 text-sm italic">Sé el primero en comentar...</p>
              )}
            </div>

            <form onSubmit={handleComment} className="p-4 bg-zinc-950 border-t border-zinc-800">
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Escribe un comentario..." 
                  className="input-field flex-1 text-sm py-2" 
                />
                <button type="submit" className="bg-red-600 p-2 rounded-lg hover:bg-red-700 transition-colors">
                  <MessageCircle size={18} />
                </button>
              </div>
            </form>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

const ProfileModal: React.FC<{ isOpen: boolean, onClose: () => void }> = ({ isOpen, onClose }) => {
  const { user, token, login } = useAuth();
  const [bio, setBio] = useState(user?.bio || '');
  const [profilePic, setProfilePic] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    const formData = new FormData();
    formData.append('bio', bio);
    if (profilePic) formData.append('profilePic', profilePic);

    try {
      const res = await fetch(`${API_BASE}/api/profile/update`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      const data = await res.json();
      if (res.ok) {
        login(token!, data);
        setMessage('Perfil actualizado con éxito');
      }
    } catch (err) {
      setMessage('Error al actualizar');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-8">
            <h2 className="text-2xl font-black mb-6">Mi Perfil</h2>
            
            <div className="flex flex-col items-center mb-8">
              <div className="w-24 h-24 bg-zinc-800 rounded-full mb-4 overflow-hidden border-4 border-zinc-800 relative group">
                {user?.profilePic ? (
                  <img src={user.profilePic} alt={user.username} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <UserIcon size={40} className="text-zinc-600 m-auto mt-6" />
                )}
                <label className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
                  <Upload size={20} />
                  <input type="file" className="hidden" onChange={(e) => setProfilePic(e.target.files?.[0] || null)} accept="image/*" />
                </label>
              </div>
              <h3 className="text-xl font-bold">@{user?.username}</h3>
              {user?.isVerified && <div className="flex items-center gap-1 text-blue-500 text-xs font-bold mt-1"><CheckCircle size={12} fill="currentColor" /> Verificado</div>}
            </div>

            <form onSubmit={handleUpdate} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase mb-2 ml-1">Biografía</label>
                <textarea 
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Cuéntanos sobre ti..." 
                  className="input-field w-full h-24 resize-none"
                />
              </div>
              
              {message && <p className="text-center text-xs font-bold text-green-500">{message}</p>}

              <button disabled={loading} type="submit" className="btn-primary w-full py-3 font-black">
                {loading ? 'GUARDANDO...' : 'GUARDAR CAMBIOS'}
              </button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const AdminPanel: React.FC = () => {
  const [targetUser, setTargetUser] = useState('');
  const [message, setMessage] = useState('');
  const { token } = useAuth();

  const handleAction = async (endpoint: string, method: string, body?: any) => {
    setMessage('');
    try {
      const res = await fetch(`${API_BASE}${endpoint}`, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: body ? JSON.stringify(body) : undefined
      });
      const data = await res.json();
      if (res.ok) setMessage('Acción completada con éxito');
      else setMessage(data.error || 'Error en la acción');
    } catch (err) {
      setMessage('Error de conexión');
    }
  };

  return (
    <section className="bg-red-600/5 border border-red-600/20 rounded-3xl p-8 mb-12">
      <div className="flex items-center gap-4 mb-6">
        <div className="p-3 bg-red-600 rounded-2xl">
          <ShieldCheck className="text-white" size={32} />
        </div>
        <div>
          <h2 className="text-2xl font-black">Panel del Amo</h2>
          <p className="text-zinc-500 text-sm font-medium">Control total sobre StreamMax.</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <CheckCircle size={18} className="text-blue-500" /> Gestionar Verificación
          </h3>
          <div className="flex gap-2">
            <input 
              type="text" 
              placeholder="Nombre de usuario (sin @)" 
              value={targetUser}
              onChange={(e) => setTargetUser(e.target.value)}
              className="input-field flex-1 text-sm" 
            />
            <button 
              onClick={() => handleAction('/api/verify', 'POST', { username: targetUser, action: 'verify' })}
              className="bg-blue-600 hover:bg-blue-700 p-2 rounded-lg transition-colors"
              title="Verificar"
            >
              <CheckCircle size={18} />
            </button>
            <button 
              onClick={() => handleAction('/api/verify', 'POST', { username: targetUser, action: 'unverify' })}
              className="bg-zinc-800 hover:bg-zinc-700 p-2 rounded-lg transition-colors"
              title="Quitar Verificación"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
          <h3 className="font-bold mb-4 flex items-center gap-2 text-red-500">
            <Trash2 size={18} /> Eliminar Cuenta
          </h3>
          <div className="flex gap-2">
            <input 
              type="text" 
              placeholder="Nombre de usuario (sin @)" 
              value={targetUser}
              onChange={(e) => setTargetUser(e.target.value)}
              className="input-field flex-1 text-sm" 
            />
            <button 
              onClick={() => {
                if(confirm(`¿ELIMINAR DEFINITIVAMENTE A @${targetUser}?`))
                  handleAction(`/api/users/${targetUser}`, 'DELETE');
              }}
              className="bg-red-600 hover:bg-red-700 px-4 rounded-lg font-bold text-xs transition-colors"
            >
              ELIMINAR
            </button>
          </div>
        </div>
      </div>
      
      {message && (
        <motion.p 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          className="text-center mt-6 text-xs font-bold text-zinc-400"
        >
          {message}
        </motion.p>
      )}

      <div className="mt-8 pt-8 border-t border-zinc-800/50">
        <p className="text-xs text-zinc-500 text-center">
          Reportes de copyright y quejas: <span className="text-white">rj757814007@gmail.com</span>
        </p>
      </div>
    </section>
  );
};

const UserProfileModal: React.FC<{ username: string | null, onClose: () => void }> = ({ username, onClose }) => {
  const [user, setUser] = useState<User | null>(null);
  const { token, user: currentUser } = useAuth();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (username) {
      setLoading(true);
      fetch(`${API_BASE}/api/users/${username}`)
        .then(res => res.json())
        .then(data => {
          setUser(data);
          setLoading(false);
        });
    }
  }, [username]);

  const handleFollow = async () => {
    if (!token || !user) return;
    try {
      const res = await fetch(`${API_BASE}/api/users/${user.username}/follow`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) {
        setUser({ ...user, followers: data.followers });
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (!username) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-8">
          {loading ? (
            <div className="py-20 text-center">Cargando...</div>
          ) : user ? (
            <>
              <div className="flex flex-col items-center mb-6">
                <div className="w-24 h-24 bg-zinc-800 rounded-full mb-4 overflow-hidden border-4 border-zinc-800">
                  {user.profilePic ? (
                    <img src={user.profilePic} alt={user.username} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <UserIcon size={40} className="text-zinc-600 m-auto mt-6" />
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <h3 className="text-2xl font-black">@{user.username}</h3>
                  {user.isVerified && <CheckCircle size={18} className="text-blue-500 fill-current" />}
                </div>
                <div className="flex gap-6 mt-4">
                  <div className="text-center">
                    <p className="text-xl font-black">{user.followers?.length || 0}</p>
                    <p className="text-[10px] text-zinc-500 uppercase font-bold">Seguidores</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xl font-black">{user.following?.length || 0}</p>
                    <p className="text-[10px] text-zinc-500 uppercase font-bold">Siguiendo</p>
                  </div>
                </div>
              </div>

              <div className="bg-zinc-800/50 p-4 rounded-2xl mb-6 border border-zinc-800">
                <p className="text-sm text-zinc-300 italic">
                  {user.bio || "Este usuario no ha escrito nada aún."}
                </p>
              </div>

              {currentUser && currentUser.username !== user.username && (
                <button 
                  onClick={handleFollow}
                  className={`w-full py-3 rounded-xl font-black transition-all ${user.followers?.includes(currentUser.username) ? 'bg-zinc-800 text-white hover:bg-zinc-700' : 'bg-white text-black hover:bg-zinc-200'}`}
                >
                  {user.followers?.includes(currentUser.username) ? 'SIGUIENDO' : 'SEGUIR'}
                </button>
              )}
            </>
          ) : (
            <div className="text-center py-10">Usuario no encontrado</div>
          )}
          <button onClick={onClose} className="absolute top-4 right-4 p-2 text-zinc-500 hover:text-white"><X size={20} /></button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

const AppContent: React.FC = () => {
  const { user } = useAuth();
  const [content, setContent] = useState<Content[]>([]);
  const [searchResults, setSearchResults] = useState<{ users: User[], content: Content[] } | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [selectedContent, setSelectedContent] = useState<Content | null>(null);
  const [viewingUser, setViewingUser] = useState<string | null>(null);

  const fetchContent = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/content`);
      const data = await res.json();
      setContent(data);
      if (selectedContent) {
        const updated = data.find((c: Content) => c.id === selectedContent.id);
        if (updated) setSelectedContent(updated);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSearch = async (query: string) => {
    if (!query.trim()) {
      setSearchResults(null);
      return;
    }
    try {
      const res = await fetch(`${API_BASE}/api/search?q=${encodeURIComponent(query)}`);
      const data = await res.json();
      setSearchResults(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchContent();
    if (!user) setIsAuthOpen(true);
  }, [user]);

  const handleAdminDelete = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar este contenido? Como amo de la app, tienes el poder total.')) return;
    
    try {
      const res = await fetch(`${API_BASE}/api/content/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      if (res.ok) fetchContent();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-red-600/30">
      <Navbar 
        onOpenUpload={() => setIsUploadOpen(true)} 
        onOpenNotifications={() => setIsNotificationsOpen(true)} 
        onOpenProfile={() => setIsProfileOpen(true)}
        onSearch={handleSearch}
      />
      <Sidebar />
      
      <MobileNav 
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
      />

      <main className="pt-24 pb-24 lg:pb-12 px-4 md:px-8 lg:ml-64">
        {user?.isAdmin && <AdminPanel />}

        {searchResults ? (
          <div className="space-y-12">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-black tracking-tighter">Resultados de búsqueda</h2>
              <button onClick={() => setSearchResults(null)} className="text-zinc-500 hover:text-white text-sm font-bold">Limpiar</button>
            </div>

            {searchResults.users.length > 0 && (
              <section>
                <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest mb-6">Creadores</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {searchResults.users.map(u => (
                    <div 
                      key={u.id} 
                      onClick={() => setViewingUser(u.username)}
                      className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800 flex flex-col items-center text-center cursor-pointer hover:border-zinc-600 transition-all"
                    >
                      <div className="w-16 h-16 bg-zinc-800 rounded-full mb-3 overflow-hidden">
                        {u.profilePic ? <img src={u.profilePic} className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : <UserIcon className="m-auto mt-4 text-zinc-600" />}
                      </div>
                      <span className="font-bold text-sm">@{u.username}</span>
                      {u.isVerified && <CheckCircle size={12} className="text-blue-500 mt-1" fill="currentColor" />}
                    </div>
                  ))}
                </div>
              </section>
            )}

            <section>
              <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest mb-6">Contenido</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {searchResults.content.map(c => (
                  <ContentCard key={c.id} content={c} onClick={() => setSelectedContent(c)} />
                ))}
              </div>
            </section>
          </div>
        ) : (
          <>
            <header className="mb-12">
              <h1 className="text-4xl md:text-6xl font-black tracking-tighter mb-4">
                Hola, <span className="text-red-600">@{user?.username || 'Invitado'}</span>
              </h1>
              <p className="text-zinc-500 max-w-2xl font-medium">
                Bienvenido a <span className="text-white">StreamMax</span>. Tu plataforma definitiva para video y música sin límites. 
                Soporte: <a href="mailto:rj757814007@gmail.com" className="text-red-500 hover:underline">rj757814007@gmail.com</a>
              </p>
            </header>

            <section className="mb-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-black flex items-center gap-2">
                  <Play className="text-red-600 fill-current" size={24} /> Tendencias
                </h2>
                <div className="flex gap-2">
                  <button className="px-4 py-1.5 bg-zinc-900 rounded-full text-xs font-bold hover:bg-zinc-800 transition-colors">Videos</button>
                  <button className="px-4 py-1.5 bg-zinc-900 rounded-full text-xs font-bold hover:bg-zinc-800 transition-colors">Música</button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
                {content.map(item => (
                  <ContentCard 
                    key={item.id} 
                    content={item} 
                    onAdminDelete={handleAdminDelete}
                    onClick={() => setSelectedContent(item)}
                  />
                ))}
                {content.length === 0 && (
                  <div className="col-span-full py-20 text-center border-2 border-dashed border-zinc-900 rounded-3xl">
                    <p className="text-zinc-500 font-bold">No hay contenido aún. ¡Sé el primero en subir algo!</p>
                  </div>
                )}
              </div>
            </section>
          </>
        )}
      </main>

      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
      <UploadModal isOpen={isUploadOpen} onClose={() => setIsUploadOpen(false)} onUploadSuccess={fetchContent} />
      <NotificationsModal isOpen={isNotificationsOpen} onClose={() => setIsNotificationsOpen(false)} />
      <ProfileModal isOpen={isProfileOpen} onClose={() => setIsProfileOpen(false)} />
      <UserProfileModal username={viewingUser} onClose={() => setViewingUser(null)} />
      <PlayerModal content={selectedContent} onClose={() => setSelectedContent(null)} onUpdate={fetchContent} />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

export default App;
