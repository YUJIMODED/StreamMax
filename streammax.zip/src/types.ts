export interface User {
  id: string;
  username: string;
  isVerified: boolean;
  isAdmin: boolean;
  profilePic?: string;
  bio?: string;
  followers?: string[];
  following?: string[];
}

export interface Content {
  id: string;
  title: string;
  type: 'video' | 'music';
  description: string;
  url: string;
  thumbnailUrl?: string;
  author: string;
  createdAt: string;
  likes: string[];
  dislikes: string[];
  comments: Comment[];
  favorites: string[];
}

export interface Comment {
  id: string;
  username: string;
  text: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  toUser: string;
  fromUser: string;
  message: string;
  contentId?: string;
  read: boolean;
  createdAt: string;
}
