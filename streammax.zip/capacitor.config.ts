import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.streammax.app',
  appName: 'StreamMax',
  webDir: 'dist'
};

export default config;
